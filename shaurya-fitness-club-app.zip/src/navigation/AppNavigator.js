import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from '../screens/HomeScreen';
import WorkoutScreen from '../screens/WorkoutScreen';

const Stack = createStackNavigator();

export default function AppNavigator() {
  return (
    <Stack.Navigator initialRouteName="Home">
      <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'शौर्य फिटनेस क्लब' }} />
      <Stack.Screen name="Workout" component={WorkoutScreen} options={{ title: 'आजचा वर्कआउट' }} />
    </Stack.Navigator>
  );
}