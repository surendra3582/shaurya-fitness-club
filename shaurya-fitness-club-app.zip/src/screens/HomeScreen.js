import React from 'react';
import { View, Text, Button, StyleSheet, Image } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Image source={require('../../assets/logo.png')} style={styles.logo} />
      <Text style={styles.title}>शौर्य फिटनेस क्लबमध्ये आपले स्वागत आहे!</Text>
      <Button title="वर्कआउट सुरू करा" onPress={() => navigation.navigate('Workout')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 22, color: '#fff', margin: 20, textAlign: 'center' },
  logo: { width: 150, height: 150, marginBottom: 20 }
});