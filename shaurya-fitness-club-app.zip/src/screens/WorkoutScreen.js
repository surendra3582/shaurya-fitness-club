import React from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';

const workouts = ['कार्डिओ', 'स्ट्रेंथ ट्रेनिंग', 'स्ट्रेचिंग', 'योगा'];

export default function WorkoutScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.heading}>आजचा वर्कआउट</Text>
      <FlatList
        data={workouts}
        keyExtractor={(item) => item}
        renderItem={({ item }) => (
          <Text style={styles.item}>{item}</Text>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', padding: 20 },
  heading: { fontSize: 26, color: '#fff', marginBottom: 20 },
  item: { fontSize: 18, color: '#ccc', paddingVertical: 10, borderBottomWidth: 0.5, borderBottomColor: '#333' }
});